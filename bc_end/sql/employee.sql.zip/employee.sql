-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2017 at 05:46 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project_pi`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `food_name` varchar(300) NOT NULL,
  `contain` text NOT NULL,
  `price` float NOT NULL,
  `type_food` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `food_name`, `contain`, `price`, `type_food`) VALUES
(1, 'Baked Dijon Salmon', ' Pineapple, Minced Beef, Cheese.', 30, 'mainFood'),
(2, 'Baked Salmon', 'Tuna, Sweetcorn, Cheese.', 50, 'mainFood'),
(3, 'Cajun Seafood Pasta 	', 'Chicken, mozzarella cheese, onions.	 	', 30, 'mainFood'),
(4, 'Creamy Pesto Shrimp 	', 'Cheese, tomato, mushrooms, onions.	', 25, 'mainFood'),
(5, 'Clams & Garlic 	', 'Cheese, tomato, mushrooms, onions.	', 50, 'mainFood'),
(6, 'Coconut Shrimp ', 'Cheese, tomato, mushrooms, onions.	', 25, 'mainFood'),
(7, 'Fish Tacos 	', 'Chicken, mozzarella cheese, onions.	', 30, 'mainFood'),
(8, 'Grilled Fish Steaks 	', 'Tuna, Sweetcorn, Cheese.	', 25, 'mainFood'),
(9, 'Garlic Shrimp Scampy 	', 'Pineapple, Minced Beef, Cheese.', 30, 'mainFood'),
(10, 'Grilled Alaska Salmon', 'Tuna, Sweetcorn, Cheese.	 	', 50, 'mainFood'),
(11, 'Grilled Salmon 	', 'Cheese, tomato, mushrooms, onions.	', 50, 'mainFood'),
(12, 'Grilled Shrimp 	', 'Chicken, mozzarella cheese, onions.	', 56, 'mainFood'),
(13, 'Maple Salmon', 'Tuna, Sweetcorn, Cheese.	', 25, 'mainFood'),
(14, 'Mussels Mariniere', 'Tuna, Sweetcorn, Cheese.	', 50, 'mainFood'),
(15, 'Lemon Garlic Tilapia ', 'Chicken, mozzarella cheese, onions.	', 62, 'mainFood'),
(16, 'Lemon Shrimp Linguini 	', 'Pineapple, Minced Beef, Cheese.	 	', 30, 'mainFood'),
(17, 'Peppered Shrimp Alfredo ', 'Tuna, Sweetcorn, Cheese.	', 25, 'mainFood'),
(18, 'Rockin Oysters', 'Pineapple, Minced Beef, Cheese.	 ', 62, 'mainFood'),
(19, 'Tuna Noodle Casserole 	', 'Pineapple, Minced Beef, Cheese.		', 62, 'mainFood'),
(20, 'Salmon Cakes', 'Chicken, mozzarella cheese, onions.	', 62, 'mainFood'),
(21, 'Sesame Seared Tuna', 'Chicken, mozzarella cheese, onions.	 	', 30, 'mainFood'),
(22, 'Shrimp Scampi Bake', 'Cheese, tomato, mushrooms, onions.	 	', 25, 'mainFood'),
(23, 'Szechwan Shrimp ', 'Pineapple, Minced Beef, Cheese.	 	', 62, 'mainFood'),
(24, 'Tuna Casserole', 'Cheese, tomato, mushrooms, onions.	 	', 50, 'mainFood'),
(25, 'Breaded Mushrooms', ' 	 			', 5.5, 'hotAppetizers'),
(26, 'Chicken Fingers 	', ' 			', 7.95, 'hotAppetizers'),
(27, 'Clams Oregarato', '	 			', 8.95, 'hotAppetizers'),
(28, 'Fried Calamari', ' 	 		', 9.95, 'hotAppetizers'),
(29, 'Fried Shrimp & Calamari ', '				', 12.5, 'hotAppetizers'),
(30, 'French Fries ', ' 			', 4, 'hotAppetizers'),
(31, 'French Fries ', 'Cheese	 	', 4.75, 'hotAppetizers'),
(32, 'Garlic Bread ', ' 				', 3.3, 'hotAppetizers'),
(33, 'Garlic Bread', 'Cheese	 	 		', 4.3, 'hotAppetizers'),
(34, 'Jalapeno Popper', ' 	 		 	', 5, 'hotAppetizers'),
(35, 'Mussels 	', 'White or Red sauce		', 9.9, 'hotAppetizers'),
(36, 'Mozzarella Sticks ', '			 	', 7, 'hotAppetizers'),
(37, 'Zucchini Sticks', ' 		 	', 6.95, 'hotAppetizers'),
(38, 'Hot wing', ' 	 		 	', 7.35, 'hotAppetizers'),
(39, 'Onion Rings', ' 	 		', 5.35, 'hotAppetizers'),
(40, 'Onion Rings', 'Cheese	', 5.95, 'hotAppetizers'),
(41, 'Antipasto', 'Small	 	', 7.95, 'salad&soup'),
(42, 'Antipasto', 'Large	 	 		', 10.25, 'salad&soup'),
(43, 'Chef Salad', ' 	 		 	', 7.5, 'salad&soup'),
(44, 'Grilled Chicken Salad ', '			', 7.5, 'salad&soup'),
(45, 'Mozzaella & Tomato Salad 		', ' 	', 6.5, 'salad&soup'),
(46, 'Mixed Salad', ' 	 	 			', 4.75, 'hotAppetizers'),
(47, 'Tuna Salad 	', ' 			', 7.5, 'salad&soup'),
(48, 'Extra Oressing 	each ', ' 			', 0.75, 'salad&soup'),
(49, 'Chicken Soup', ' 		 		 	', 4.5, 'salad&soup'),
(50, 'Minestrone', ' 	 			', 4.5, 'salad&soup'),
(51, 'Mushrooms Soup 	', ' 			', 3.5, 'salad&soup'),
(52, 'Passta Fagioli Soup', ' 	 		', 4.5, 'salad&soup'),
(53, 'Broccoli Saute', ' 	 		 	', 4.95, 'vegetable'),
(54, 'Escarole Saute 	', ' 			', 4.95, 'vegetable'),
(55, 'Spinach Saute', ' 	 		 	', 4.95, 'vegetable'),
(56, 'String Beans Saute 	', '		 	', 4.95, 'vegetable'),
(57, 'String Beans Marinara', ' 		 	', 4.95, 'vegetable'),
(58, 'Bruschetta de Flageolets 	', '', 19, 'dinnerMenu'),
(59, 'Champignon Portabella ', ' 			', 22, 'dinnerMenu'),
(60, 'Crepe au Fromage de Chevre', '', 21, 'dinnerMenu'),
(61, ' Crepe au Fromage de Brie', ' 			', 21.75, 'dinnerMenu'),
(62, 'Crevettes Sauce Boursin', ' 		', 23.2, 'dinnerMenu'),
(63, 'Escargots Bourguignon', ' 	 		 	', 21.5, 'dinnerMenu'),
(64, 'Moules Marinieres ou a la creme', '', 20.5, 'dinnerMenu'),
(65, 'Pate Maison', ' 	 		 	', 20.5, 'dinnerMenu'),
(66, 'Saumon Fume', '			 	', 23.5, 'dinnerMenu');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
